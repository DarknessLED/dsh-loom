// Audit the panel in a real browser: contrast, truncation, overflow, fonts.
//
// The preview says what the panel looks like; this says whether it *works* —
// whether the ink actually reads on both canvases, whether a label is clipped
// where nothing declares a clamp, whether the mono figures really render in a
// mono face. It drives headless Chrome over the same generated preview and
// reads back a JSON audit the page writes into itself.
//
//   node scripts/panel-audit.mjs
//
// Exits non-zero when a finding is a defect rather than a deliberate ellipsis.
import { execFileSync } from 'node:child_process'
import { existsSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const here = dirname(fileURLToPath(import.meta.url))
const root = join(here, '..')
const preview = join(root, 'docs', 'panel-preview.html')
const CHROME_CANDIDATES = [
  'C:/Program Files/Google/Chrome/Application/chrome.exe',
  'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe',
  'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
  'C:/Program Files/Microsoft/Edge/Application/msedge.exe',
]

if (!existsSync(preview)) {
  console.error('missing ' + preview + ' — run: node scripts/panel-preview.mjs')
  process.exit(1)
}
const chrome = CHROME_CANDIDATES.find((p) => existsSync(p))
if (!chrome) {
  console.error('no Chrome or Edge found; skipping the browser audit')
  process.exit(0)
}

const AUDIT = `
<script>
(function () {
  // Chrome serialises color-mix() results as color(srgb 0.99 0.99 0.99 / .62)
  // — 0..1 floats, in a colour space canvas2d's fillStyle will not accept. So
  // parse the serialised forms directly: hex, rgb/rgba (0–255), and CSS Color 4
  // color(srgb …) (0–1). Alpha is composited over the resolved background,
  // because that composite is what the eye actually gets.
  function norm(color) {
    var s = String(color).trim();
    if (s.charAt(0) === '#') {
      var hex = s.slice(1);
      if (hex.length === 3) hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
      return [
        parseInt(hex.slice(0, 2), 16) / 255,
        parseInt(hex.slice(2, 4), 16) / 255,
        parseInt(hex.slice(4, 6), 16) / 255,
        hex.length >= 8 ? parseInt(hex.slice(6, 8), 16) / 255 : 1,
      ];
    }
    if (s.indexOf('color(') === 0) {
      var cm = s.match(/[\\d.]+/g) || [];
      var scale = /srgb-linear|srgb/i.test(s) ? 1 : 1;
      return [
        Math.min(1, parseFloat(cm[0]) * scale),
        Math.min(1, parseFloat(cm[1]) * scale),
        Math.min(1, parseFloat(cm[2]) * scale),
        cm.length > 3 ? parseFloat(cm[3]) : 1,
      ];
    }
    var m = s.match(/[\\d.]+/g) || [];
    if (m.length < 3) return [0, 0, 0, 1];
    var pct = s.indexOf('%') >= 0 ? 2.55 : 1;
    return [
      Math.min(1, (parseFloat(m[0]) * pct) / 255),
      Math.min(1, (parseFloat(m[1]) * pct) / 255),
      Math.min(1, (parseFloat(m[2]) * pct) / 255),
      m.length > 3 ? parseFloat(m[3]) : 1,
    ];
  }
  function over(fg, bg) {
    var a = fg[3];
    return [fg[0] * a + bg[0] * (1 - a), fg[1] * a + bg[1] * (1 - a), fg[2] * a + bg[2] * (1 - a), 1];
  }
  function lum(c) {
    var f = [c[0], c[1], c[2]].map(function (x) { return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4) });
    return 0.2126 * f[0] + 0.7152 * f[1] + 0.0722 * f[2];
  }
  function ratio(fg, bg) {
    // bg may arrive as a flat colour or as an already-composited stack (an array);
    // text on a translucent card has to be measured against what the eye sees.
    var B = bg && bg.length === 4 ? bg : norm(bg);
    var f = over(norm(fg), B);
    var l1 = lum(f), l2 = lum(B), hi = Math.max(l1, l2), lo = Math.min(l1, l2);
    return (hi + 0.05) / (lo + 0.05);
  }
  function bgOf(el) {
    // Walk up collecting every translucent surface, then composite them onto the
    // first opaque one. Stopping at the first non-transparent colour (what this
    // used to do) measures a 1.5%-tint card as if it were solid ink, which
    // reports every label inside it as 1.00:1.
    var layers = [];
    var base = null;
    var n = el;
    while (n && n !== document.documentElement) {
      var b = getComputedStyle(n).backgroundColor;
      var c = b && b !== 'transparent' ? norm(b) : null;
      if (c && c[3] > 0) {
        if (c[3] >= 0.999) { base = c; break; }
        layers.push(c);
      }
      n = n.parentElement;
    }
    if (!base) base = norm(getComputedStyle(document.body).backgroundColor);
    if (!base || base[3] < 0.999) base = [1, 1, 1, 1];
    var out = base;
    for (var i = layers.length - 1; i >= 0; i--) out = over(layers[i], out);
    return out;
  }
  function hasOwnText(el) {
    for (var i = 0; i < el.childNodes.length; i++) {
      if (el.childNodes[i].nodeType === 3 && el.childNodes[i].textContent.trim().length > 0) return true;
    }
    return false;
  }
  var out = { canvases: [], truncated: 0, clipped: [], overright: [], contrast: [], shadows: 0, fonts: {}, dots: 0 };
  var canvases = document.querySelectorAll('.canvas');
  for (var i = 0; i < canvases.length; i++) {
    var cv = canvases[i];
    var name = (cv.classList.contains('dark') ? 'dark' : 'light') + (cv.classList.contains('wide') ? '-wide' : '');
    var panel = cv.querySelector('.loom');
    var scroller = panel.querySelector('.loom-scroll');
    // A grid that never grows a second track is a column with extra steps: this
    // is the number that says whether the wide layout actually uses its room.
    var tracks = function (sel) {
      var el = panel.querySelector(sel);
      if (!el) return 0;
      var t = getComputedStyle(el).gridTemplateColumns;
      return t && t !== 'none' ? t.split(' ').filter(function (x) { return x.length > 0 }).length : 0;
    };
    out.canvases.push({
      name: name,
      panelWidth: Math.round(panel.getBoundingClientRect().width),
      scroller: Math.round(scroller.clientHeight) + '/' + Math.round(scroller.scrollHeight),
      scrolls: scroller.scrollHeight > scroller.clientHeight + 1,
      hScroll: panel.scrollWidth > panel.clientWidth + 1 || scroller.scrollWidth > scroller.clientWidth + 1,
      cardColumns: tracks('.loom-cards'),
      knowledgeColumns: tracks('.loom-kgrid'),
      dividers: cv.querySelectorAll('.loom-head, .loom-metrics, .loom-row, .loom-camp, .loom-foot').length
    });
    // A child that reaches past the panel's right edge is not a scrollbar: the
    // panel clips it (overflow-x:hidden), so the text or the button simply is not
    // there any more. scrollWidth cannot see it, which is how three checkpoint
    // buttons once became invisible at 320px while the audit stayed green.
    var panelRight = panel.getBoundingClientRect().right;
    var beyond = [];
    panel.querySelectorAll('*').forEach(function (el) {
      var r = el.getBoundingClientRect();
      var over = Math.round(r.right - panelRight);
      if (over > 1) beyond.push(over);
      if (over > 1) {
        var cls = String(el.className || el.tagName);
        var txt = (el.textContent || '').trim().slice(0, 20);
        out.overright.push(name + ' ' + cls + ' +' + over + 'px "' + txt + '"');
      }
    });
    out.canvases[out.canvases.length - 1].overright = beyond.length;
    var all = panel.querySelectorAll('*');
    for (var j = 0; j < all.length; j++) {
      var el = all[j];
      var cs = getComputedStyle(el);
      if (cs.boxShadow && cs.boxShadow !== 'none') out.shadows++;
      if (/loom-dot/.test(el.className || '')) out.dots++;
      // overflow only counts when the element itself holds the text and has no
      // clamp/ellipsis of its own: a parent's scrollWidth also measures a child
      // that is deliberately truncating.
      var overPx = el.scrollWidth - el.clientWidth;
      var clamped = cs.textOverflow === 'ellipsis' || (cs.webkitLineClamp && cs.webkitLineClamp !== 'none' && cs.webkitLineClamp !== '');
      if (overPx > 1 && hasOwnText(el)) {
        if (clamped || cs.overflow === 'hidden') out.truncated++;
        else out.clipped.push(name + ' ' + (el.className || el.tagName) + ' +' + overPx + 'px "%' + (el.textContent || '').trim().slice(0, 24) + '"');
      }
      if (el.childNodes.length === 1 && hasOwnText(el)) {
        var txt = (el.textContent || '').trim();
        if (txt.length > 1 && txt.length < 80) {
          var r = ratio(cs.color, bgOf(el));
          var size = parseFloat(cs.fontSize);
          var floor = size >= 13 ? 4.5 : 3.8;
          if (r < floor) out.contrast.push(name + ' ' + size + 'px ' + (el.className || el.tagName) + ' ' + r.toFixed(2) + ' "' + txt.slice(0, 28) + '"');
        }
      }
      if (/loom-metric|loom-name|loom-age|loom-meta|loom-mark|loom-state/.test(el.className || '')) {
        var fam = cs.fontFamily.split(',')[0].replace(/"/g, '');
        out.fonts[el.className] = fam;
      }
    }
    // the figures an engineer scans by shape must really be in a mono face
    var wanted = ['.loom-mark', '.loom-metric b', '.loom-name', '.loom-age', '.loom-meta', '.loom-state', '.loom-chain', '.loom-cp-head b', '.loom-lesson .score'];
    for (var kw = 0; kw < wanted.length; kw++) {
      var pick = panel.querySelector(wanted[kw]);
      if (pick) out.fonts[wanted[kw]] = getComputedStyle(pick).fontFamily.split(',')[0].replace(/"/g, '');
    }
  }
  out.truncatedPerCanvas = Math.round(out.truncated / canvases.length);
  // Geometry is not the whole page. The preview used to drop every aria-*,
  // role and tabindex on the floor, so this script could not see the panel's
  // keyboard contract at all — it certified a page no browser ever serves, and a
  // regression in the accessibility work could never fail here. These four
  // facts are cheap and they are the ones that break silently.
  var first = document.querySelector('.canvas .loom');
  if (first) {
    var buttons = Array.prototype.slice.call(first.querySelectorAll('button'));
    out.a11y = {
      aria: first.querySelectorAll('[aria-label],[aria-live],[aria-checked],[aria-expanded],[aria-disabled]').length,
      roles: first.querySelectorAll('[role]').length,
      tabbable: first.querySelectorAll('[tabindex]').length,
      switchRole: !!first.querySelector('[role="switch"]'),
      switchChecked: !!first.querySelector('[role="switch"][aria-checked]'),
      liveRegion: !!first.querySelector('[aria-live]'),
      unnamed: buttons.filter(function (b) {
        return !(b.getAttribute('aria-label') || (b.textContent || '').trim() || b.getAttribute('title'))
      }).length,
    }
  }
  var pre = document.createElement('pre');
  pre.id = 'loom-audit';
  pre.textContent = JSON.stringify(out);
  document.body.appendChild(pre);
})();
</script>
`

const dir = mkdtempSync(join(tmpdir(), 'loom-audit-'))
const page = join(dir, 'audit.html')
writeFileSync(page, readFileSync(preview, 'utf8').replace('</body>', AUDIT + '</body>'))

let dom = ''
try {
  dom = execFileSync(
    chrome,
    ['--headless=new', '--disable-gpu', '--hide-scrollbars', '--user-data-dir=' + join(dir, 'profile'), '--virtual-time-budget=1500', '--window-size=900,1500', '--dump-dom', 'file:///' + page.replace(/\\/g, '/')],
    { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'], timeout: 60_000 },
  )
} finally {
  rmSync(dir, { recursive: true, force: true })
}

const m = dom.match(/<pre id="loom-audit">([\s\S]*?)<\/pre>/)
if (!m) {
  console.error('the audit did not run (no #loom-audit in the DOM)')
  process.exit(1)
}
const data = JSON.parse(m[1].replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>'))

for (const c of data.canvases) {
  console.log(
    `${c.name.padEnd(10)} ${String(c.panelWidth).padStart(3)}px wide · scroller ${c.scroller}px${c.scrolls ? ' (scrolls)' : ' (fits)'} · ` +
      `${c.hScroll ? 'HORIZONTAL OVERFLOW' : 'no h-overflow'} · ${c.overright ? c.overright + ' clipped' : 'nothing clipped'} · ${c.dividers} hairlines · ` +
      `${c.cardColumns} card column(s) · ${c.knowledgeColumns} knowledge column(s)`,
  )
}
console.log('font: ' + Object.entries(data.fonts).map(([k, v]) => `${k}=${v}`).join(' '))
console.log(`truncations: ${data.truncatedPerCanvas} ellipsised nodes per canvas (by design)`)
console.log(`shadows: ${data.shadows} · state dots: ${data.dots} (one shadow each)`)
if (data.a11y) {
  const a = data.a11y
  console.log(`a11y: ${a.aria} aria attrs · ${a.roles} roles · ${a.tabbable} tabindex · switch=${a.switchRole}/${a.switchChecked ? 'checked' : 'no-checked'} · live=${a.liveRegion ? 'yes' : 'no'} · unnamed buttons ${a.unnamed}`)
}

const problems = []
if (data.canvases.some((c) => c.hScroll)) problems.push('a canvas scrolls horizontally')
if (data.overright.length) problems.push('nodes reach past the panel edge and are clipped away:\n  ' + data.overright.slice(0, 8).join('\n  '))
if (data.clipped.length) problems.push('unclipped overflow: ' + data.clipped.slice(0, 6).join(', '))
if (data.contrast.length) problems.push('contrast below floor:\n  ' + data.contrast.slice(0, 10).join('\n  '))
if (data.shadows > data.canvases.length) problems.push(`too many shadows (${data.shadows} across ${data.canvases.length} canvases)`)
for (const c of data.canvases) {
  // Room given must be used, and room not given must not be faked.
  if (c.panelWidth >= 640 && c.cardColumns < 2) {
    problems.push(`${c.name} is ${c.panelWidth}px wide but still stacks campaigns in one column`)
  }
  if (c.panelWidth < 360 && c.cardColumns > 1) {
    problems.push(`${c.name} is only ${c.panelWidth}px wide but squeezes campaigns into ${c.cardColumns} columns`)
  }
  if (c.panelWidth >= 380 && c.knowledgeColumns < 2) {
    problems.push(`${c.name} has room for two knowledge columns but renders ${c.knowledgeColumns}`)
  }
}

if (data.a11y) {
  // A button with no name is a button a screen reader calls "button". The
  // switch must say whether it is on. The queue must announce itself when it
  // changes. These are the three that a geometry-only audit cannot catch.
  if (!data.a11y.switchRole || !data.a11y.switchChecked) problems.push('the loop switch does not expose role="switch" with aria-checked')
  if (!data.a11y.liveRegion) problems.push('the waiting area is not a live region, so a new checkpoint is silent')
  if (data.a11y.unnamed > 0) problems.push(`${data.a11y.unnamed} button(s) have no accessible name`)
  if (data.a11y.roles < 4) problems.push(`only ${data.a11y.roles} elements carry a role — the panel is barely navigable`)
}
if (problems.length) {
  console.error('\nFAIL\n- ' + problems.join('\n- '))
  process.exit(1)
}
console.log('\nOK — every canvas reads, nothing overflows, contrast clears the floor.')
